import { BellIcon, MenuIcon } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useState } from "react";
import { getInitials, formatDateTime } from "@/lib/utils";
import UserMenu from "./user-menu";
import wugwebLogo from "../assets/wugweb-logo.png";

interface HeaderProps {
  title: string;
  onMenuClick: () => void;
}

export default function Header({ title, onMenuClick }: HeaderProps) {
  const { user } = useAuth();
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  
  if (!user) return null;
  
  const initials = getInitials(user.firstName, user.lastName);
  const lastLoginTime = user.lastLogin ? formatDateTime(user.lastLogin) : "Unknown";
  
  return (
    <header className="bg-white shadow-sm">
      <div className="px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={onMenuClick} 
            className="lg:hidden mr-3 text-neutral-dark focus:outline-none"
            aria-label="Toggle menu"
          >
            <MenuIcon className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-3">
            <img src={wugwebLogo} alt="Wugweb Logo" className="h-8 w-8" />
            <h2 className="text-xl font-heading font-semibold">{title}</h2>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="relative">
            <button 
              className="flex items-center text-neutral-dark hover:text-primary transition-colors focus:outline-none"
              aria-label="Notifications"
            >
              <BellIcon className="w-6 h-6" />
              <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-primary"></span>
            </button>
          </div>
          
          <div className="relative">
            <button 
              className="flex items-center space-x-2 focus:outline-none" 
              id="user-menu-button"
              onClick={() => setUserMenuOpen(!userMenuOpen)}
              aria-expanded={userMenuOpen}
              aria-haspopup="true"
            >
              <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center text-white">
                {user.avatar ? (
                  <img 
                    src={user.avatar} 
                    alt={`${user.firstName} ${user.lastName}`}
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <span>{initials}</span>
                )}
              </div>
              <div className="hidden md:block text-left">
                <div className="text-sm font-medium">{`${user.firstName} ${user.lastName}`}</div>
                <div className="text-xs text-neutral-medium">{user.position}</div>
              </div>
              <svg className="w-5 h-5 text-neutral-medium" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
              </svg>
            </button>
            
            {userMenuOpen && (
              <UserMenu onClose={() => setUserMenuOpen(false)} />
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
