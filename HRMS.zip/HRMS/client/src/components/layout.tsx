import { useState, useEffect } from "react";
import Sidebar from "./sidebar";
import Header from "./header";
import { useLocation } from "wouter";

interface LayoutProps {
  children: React.ReactNode;
  title?: string;
}

export default function Layout({ children, title = "Dashboard" }: LayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [, setLocation] = useLocation();
  
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };
  
  // Close mobile menu when route changes
  useEffect(() => {
    return () => {
      setMobileMenuOpen(false);
    };
  }, [setLocation]);
  
  // Add overflow-hidden to body when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }
    
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [mobileMenuOpen]);
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile menu overlay */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-neutral-darkest opacity-50 z-20 lg:hidden"
          onClick={toggleMobileMenu}
        />
      )}
      
      {/* Sidebar */}
      <Sidebar 
        isOpen={mobileMenuOpen} 
        onClose={() => setMobileMenuOpen(false)} 
      />
      
      {/* Main content */}
      <main className="flex-1 overflow-y-auto bg-neutral-lightest lg:ml-64">
        <Header 
          title={title} 
          onMenuClick={toggleMobileMenu} 
        />
        {children}
      </main>
    </div>
  );
}
