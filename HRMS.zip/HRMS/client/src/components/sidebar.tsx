import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { 
  HomeIcon, 
  ClipboardListIcon, 
  FileTextIcon, 
  BarChartIcon, 
  UserIcon, 
  SettingsIcon, 
  LogOutIcon, 
  FileIcon, 
  UsersIcon, 
  BookOpenIcon, 
  HeartIcon,
  BanknoteIcon,
  FilePenIcon
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { logout } = useAuth();
  
  const handleLogout = (e: React.MouseEvent) => {
    e.preventDefault();
    logout();
  };
  
  const isActive = (path: string) => {
    return location === path || location === path + "/";
  };
  
  return (
    <aside 
      className={cn(
        "w-64 h-full bg-white shadow-lg fixed inset-y-0 left-0 transform transition-transform duration-200 ease-in-out z-30 lg:z-0 overflow-y-auto",
        isOpen ? "translate-x-0" : "-translate-x-full",
        "lg:translate-x-0"
      )}
    >
      <div className="p-4 border-b">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-heading font-bold">
            HR
          </div>
          <h1 className="text-xl font-heading font-semibold text-primary">HRConnect</h1>
        </div>
      </div>
      
      <div className="py-4">
        <div className="px-4 mb-4">
          <span className="text-neutral-medium text-sm font-medium">MAIN</span>
        </div>
        <nav>
          <Link 
            href="/dashboard" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/dashboard") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <HomeIcon className="w-5 h-5 mr-3" />
            <span>Dashboard</span>
          </Link>
          
          <Link 
            href="/onboarding" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/onboarding") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <ClipboardListIcon className="w-5 h-5 mr-3" />
            <span>Onboarding</span>
          </Link>
          
          <Link 
            href="/salary-slips" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/salary-slips") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <BanknoteIcon className="w-5 h-5 mr-3" />
            <span>Salary Slips</span>
          </Link>
          
          <Link 
            href="/documents" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/documents") || location.startsWith("/documents/") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <FileTextIcon className="w-5 h-5 mr-3" />
            <span>Documents</span>
          </Link>
          
          <Link 
            href="/document-generator" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/document-generator") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <FilePenIcon className="w-5 h-5 mr-3" />
            <span>Document Generator</span>
          </Link>
        </nav>
        
        <div className="px-4 my-4">
          <span className="text-neutral-medium text-sm font-medium">COMPANY</span>
        </div>
        <nav>
          <Link 
            href="/employee-directory" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/employee-directory") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <UsersIcon className="w-5 h-5 mr-3" />
            <span>Employee Directory</span>
          </Link>
          
          <Link 
            href="/knowledge-sharing" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/knowledge-sharing") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <BookOpenIcon className="w-5 h-5 mr-3" />
            <span>Knowledge Sharing</span>
          </Link>
          
          <Link 
            href="/benefits-administration" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/benefits-administration") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <HeartIcon className="w-5 h-5 mr-3" />
            <span>Benefits</span>
          </Link>
          
          <Link 
            href="/reports" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/reports") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <BarChartIcon className="w-5 h-5 mr-3" />
            <span>Reports</span>
          </Link>
        </nav>
        
        <div className="px-4 my-4">
          <span className="text-neutral-medium text-sm font-medium">ACCOUNT</span>
        </div>
        <nav>
          <Link 
            href="/profile" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/profile") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <UserIcon className="w-5 h-5 mr-3" />
            <span>Profile</span>
          </Link>
          
          <Link 
            href="/employee-profile" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/employee-profile") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <FileTextIcon className="w-5 h-5 mr-3" />
            <span>Employment Info</span>
          </Link>
          
          <Link 
            href="/settings" 
            onClick={onClose}
            className={cn(
              "flex items-center px-4 py-3 hover:bg-primary-light hover:bg-opacity-10 hover:text-primary transition-colors",
              isActive("/settings") ? "text-primary bg-primary-light bg-opacity-10 border-l-4 border-primary" : "text-neutral-dark border-l-4 border-transparent"
            )}
          >
            <SettingsIcon className="w-5 h-5 mr-3" />
            <span>Settings</span>
          </Link>
        </nav>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t">
        <a 
          href="#" 
          onClick={handleLogout}
          className="flex items-center text-neutral-dark hover:text-error transition-colors"
        >
          <LogOutIcon className="w-5 h-5 mr-3" />
          <span>Logout</span>
        </a>
      </div>
    </aside>
  );
}
