import React, { useState } from "react";
import Layout from "@/components/layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { 
  FileText, Download, FilePlus, CheckCircle2, 
  Info, AlertCircle, FileOutput, Printer
} from "lucide-react";

// Document templates
type DocumentTemplate = {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  fields: DocumentField[];
  generateDocument: (data: any) => string;
};

type DocumentField = {
  id: string;
  label: string;
  type: 'text' | 'date' | 'textarea' | 'select';
  required: boolean;
  options?: { value: string; label: string }[];
  placeholder?: string;
};

const jobOfferTemplate: DocumentTemplate = {
  id: "job-offer",
  name: "Job Offer Letter",
  description: "Generate a job offer letter with complete details about position, salary, and terms",
  icon: <FilePlus className="w-5 h-5" />,
  fields: [
    { id: "candidateName", label: "Candidate Full Name", type: "text", required: true, placeholder: "John Doe" },
    { id: "position", label: "Position Title", type: "text", required: true, placeholder: "Software Engineer" },
    { id: "department", label: "Department", type: "text", required: true, placeholder: "Engineering" },
    { id: "startDate", label: "Start Date", type: "date", required: true },
    { id: "salary", label: "Annual Salary", type: "text", required: true, placeholder: "₹10,00,000" },
    { id: "location", label: "Work Location", type: "text", required: true, placeholder: "Noida, UP" },
    { id: "reportingTo", label: "Reporting To", type: "text", required: true, placeholder: "Jane Smith, Engineering Manager" },
    { id: "additionalNotes", label: "Additional Notes", type: "textarea", required: false, placeholder: "Any additional details about the offer..." }
  ],
  generateDocument: (data) => {
    const currentDate = format(new Date(), "MMMM dd, yyyy");
    return `
      <div class="document">
        <div class="document-header">
          <img src="__LOGO_URL__" alt="Company Logo" class="logo" />
          <h1>Job Offer Letter</h1>
          <p class="date">${currentDate}</p>
        </div>
        
        <div class="document-body">
          <p>Dear ${data.candidateName},</p>
          
          <p>We are pleased to offer you the position of <strong>${data.position}</strong> in the ${data.department} department at Wug Web Design. 
          This letter outlines the terms and conditions of your employment offer.</p>
          
          <h2>Position Details</h2>
          <ul>
            <li><strong>Title:</strong> ${data.position}</li>
            <li><strong>Department:</strong> ${data.department}</li>
            <li><strong>Reporting To:</strong> ${data.reportingTo}</li>
            <li><strong>Start Date:</strong> ${format(new Date(data.startDate), "MMMM dd, yyyy")}</li>
            <li><strong>Location:</strong> ${data.location}</li>
          </ul>
          
          <h2>Compensation</h2>
          <p>Your annual gross salary will be ${data.salary}, paid in monthly installments.</p>
          
          <h2>Additional Notes</h2>
          <p>${data.additionalNotes || "N/A"}</p>
          
          <p>This offer is contingent upon successful completion of background verification and reference checks. 
          To accept this offer, please sign and return this letter by [Response Date].</p>
          
          <p>We are excited about the possibility of you joining our team and look forward to welcoming you aboard!</p>
          
          <p>Sincerely,</p>
          <p>HR Department<br />Wug Web Design</p>
        </div>
        
        <div class="document-footer">
          <div class="signature-section">
            <div class="signature-line">
              <p>Accepted By: ${data.candidateName}</p>
              <div class="line"></div>
            </div>
            <div class="signature-line">
              <p>Date:</p>
              <div class="line"></div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
};

const ndaTemplate: DocumentTemplate = {
  id: "nda",
  name: "Non-Disclosure Agreement",
  description: "Generate a standard Non-Disclosure Agreement for employees",
  icon: <FileText className="w-5 h-5" />,
  fields: [
    { id: "employeeName", label: "Employee Full Name", type: "text", required: true, placeholder: "John Doe" },
    { id: "employeeAddress", label: "Employee Address", type: "text", required: true, placeholder: "123 Main St, City, State" },
    { id: "effectiveDate", label: "Effective Date", type: "date", required: true },
    { id: "duration", label: "Agreement Duration (Years)", type: "select", required: true, options: [
      { value: "1", label: "1 Year" },
      { value: "2", label: "2 Years" },
      { value: "3", label: "3 Years" },
      { value: "5", label: "5 Years" },
      { value: "indefinite", label: "Indefinite" }
    ]},
    { id: "specialTerms", label: "Special Terms", type: "textarea", required: false, placeholder: "Any special terms or conditions..." }
  ],
  generateDocument: (data) => {
    const currentDate = format(new Date(), "MMMM dd, yyyy");
    const effectiveDate = format(new Date(data.effectiveDate), "MMMM dd, yyyy");
    const duration = data.duration === "indefinite" ? "indefinite period" : `${data.duration} year(s)`;
    
    return `
      <div class="document">
        <div class="document-header">
          <img src="__LOGO_URL__" alt="Company Logo" class="logo" />
          <h1>Non-Disclosure Agreement</h1>
          <p class="date">${currentDate}</p>
        </div>
        
        <div class="document-body">
          <p>This Non-Disclosure Agreement (the "Agreement") is entered into on ${effectiveDate} by and between:</p>
          
          <p><strong>Wug Web Design</strong>, with its principal place of business at WeWork Berger Delhi One, Floor 19, C-001/A2, Sector 16B, Noida, UP- 201301, IN (the "Company")</p>
          
          <p>and</p>
          
          <p><strong>${data.employeeName}</strong>, residing at ${data.employeeAddress} (the "Employee").</p>
          
          <h2>1. Purpose</h2>
          <p>The purpose of this Agreement is to protect the confidential and proprietary information of the Company that may be disclosed to the Employee during their employment.</p>
          
          <h2>2. Definition of Confidential Information</h2>
          <p>For purposes of this Agreement, "Confidential Information" means any information disclosed by the Company to the Employee, either directly or indirectly, in writing, orally, or by inspection of tangible objects, including without limitation: business plans, customer lists, financial information, technical data, product ideas, software, algorithms, and other business information.</p>
          
          <h2>3. Term</h2>
          <p>This Agreement shall remain in effect for a ${duration} from the Effective Date.</p>
          
          <h2>4. Special Terms</h2>
          <p>${data.specialTerms || "No special terms specified."}</p>
          
          <p>IN WITNESS WHEREOF, the parties have executed this Agreement as of the Effective Date.</p>
        </div>
        
        <div class="document-footer">
          <div class="signature-section">
            <div class="signature-block">
              <p>Wug Web Design</p>
              <div class="line"></div>
              <p>By: ___________________</p>
              <p>Title: ___________________</p>
            </div>
            
            <div class="signature-block">
              <p>Employee</p>
              <div class="line"></div>
              <p>${data.employeeName}</p>
            </div>
          </div>
        </div>
      </div>
    `;
  }
};

const relievingLetterTemplate: DocumentTemplate = {
  id: "relieving-letter",
  name: "Relieving Letter",
  description: "Generate a relieving letter for departing employees",
  icon: <FileOutput className="w-5 h-5" />,
  fields: [
    { id: "employeeName", label: "Employee Full Name", type: "text", required: true, placeholder: "John Doe" },
    { id: "employeeId", label: "Employee ID", type: "text", required: true, placeholder: "EMP-12345" },
    { id: "position", label: "Last Position Held", type: "text", required: true, placeholder: "Senior Developer" },
    { id: "department", label: "Department", type: "text", required: true, placeholder: "Engineering" },
    { id: "joiningDate", label: "Date of Joining", type: "date", required: true },
    { id: "lastDate", label: "Last Working Date", type: "date", required: true },
    { id: "reason", label: "Reason for Separation", type: "select", required: true, options: [
      { value: "resignation", label: "Resignation" },
      { value: "termination", label: "Termination" },
      { value: "layoff", label: "Layoff" },
      { value: "retirement", label: "Retirement" },
      { value: "contract-end", label: "End of Contract" }
    ]},
    { id: "additionalNotes", label: "Additional Notes", type: "textarea", required: false, placeholder: "Any additional details..." }
  ],
  generateDocument: (data) => {
    const currentDate = format(new Date(), "MMMM dd, yyyy");
    const joiningDate = format(new Date(data.joiningDate), "MMMM dd, yyyy");
    const lastDate = format(new Date(data.lastDate), "MMMM dd, yyyy");
    
    let reasonText = "";
    switch(data.reason) {
      case "resignation":
        reasonText = "voluntary resignation";
        break;
      case "termination":
        reasonText = "termination of employment";
        break;
      case "layoff":
        reasonText = "organizational restructuring";
        break;
      case "retirement":
        reasonText = "retirement";
        break;
      case "contract-end":
        reasonText = "completion of contract period";
        break;
      default:
        reasonText = "separation from the company";
    }
    
    return `
      <div class="document">
        <div class="document-header">
          <img src="__LOGO_URL__" alt="Company Logo" class="logo" />
          <h1>Relieving Letter</h1>
          <p class="date">${currentDate}</p>
          <p class="ref">Ref: HR/REL/${data.employeeId}</p>
        </div>
        
        <div class="document-body">
          <p>To Whomsoever It May Concern</p>
          
          <p>This is to certify that <strong>${data.employeeName}</strong> (Employee ID: ${data.employeeId}) was employed with Wug Web Design as <strong>${data.position}</strong> in the ${data.department} department from ${joiningDate} to ${lastDate}.</p>
          
          <p>This letter confirms that ${data.employeeName} has been relieved of all duties and responsibilities at Wug Web Design effective ${lastDate} due to ${reasonText}.</p>
          
          <p>During their tenure with us, ${data.employeeName} demonstrated professionalism and completed all assigned responsibilities to our satisfaction. All company properties and confidential information have been returned and all dues have been settled.</p>
          
          ${data.additionalNotes ? `<p>${data.additionalNotes}</p>` : ''}
          
          <p>We wish ${data.employeeName} all the best for their future endeavors.</p>
          
          <p>Sincerely,</p>
          <p>Human Resources<br />Wug Web Design</p>
        </div>
      </div>
    `;
  }
};

const experienceLetterTemplate: DocumentTemplate = {
  id: "experience-letter",
  name: "Experience Letter",
  description: "Generate an experience letter detailing employee's work history",
  icon: <CheckCircle2 className="w-5 h-5" />,
  fields: [
    { id: "employeeName", label: "Employee Full Name", type: "text", required: true, placeholder: "John Doe" },
    { id: "employeeId", label: "Employee ID", type: "text", required: true, placeholder: "EMP-12345" },
    { id: "position", label: "Last Position Held", type: "text", required: true, placeholder: "Senior Developer" },
    { id: "department", label: "Department", type: "text", required: true, placeholder: "Engineering" },
    { id: "joiningDate", label: "Date of Joining", type: "date", required: true },
    { id: "lastDate", label: "Last Working Date", type: "date", required: true },
    { id: "responsibilities", label: "Key Responsibilities", type: "textarea", required: true, placeholder: "List key responsibilities and achievements..." },
    { id: "projects", label: "Major Projects", type: "textarea", required: false, placeholder: "List major projects worked on..." }
  ],
  generateDocument: (data) => {
    const currentDate = format(new Date(), "MMMM dd, yyyy");
    const joiningDate = format(new Date(data.joiningDate), "MMMM dd, yyyy");
    const lastDate = format(new Date(data.lastDate), "MMMM dd, yyyy");
    
    // Calculate years of experience
    const start = new Date(data.joiningDate);
    const end = new Date(data.lastDate);
    const years = end.getFullYear() - start.getFullYear();
    const months = end.getMonth() - start.getMonth();
    
    let experiencePeriod = "";
    if (years > 0) {
      experiencePeriod += `${years} year${years > 1 ? 's' : ''}`;
    }
    if (months > 0) {
      experiencePeriod += experiencePeriod ? ` and ${months} month${months > 1 ? 's' : ''}` : `${months} month${months > 1 ? 's' : ''}`;
    }
    if (!experiencePeriod) {
      experiencePeriod = "less than a month";
    }
    
    return `
      <div class="document">
        <div class="document-header">
          <img src="__LOGO_URL__" alt="Company Logo" class="logo" />
          <h1>Experience Letter</h1>
          <p class="date">${currentDate}</p>
          <p class="ref">Ref: HR/EXP/${data.employeeId}</p>
        </div>
        
        <div class="document-body">
          <p>To Whomsoever It May Concern</p>
          
          <p>This is to certify that <strong>${data.employeeName}</strong> (Employee ID: ${data.employeeId}) was employed with Wug Web Design as <strong>${data.position}</strong> in the ${data.department} department from ${joiningDate} to ${lastDate}, spanning a period of ${experiencePeriod}.</p>
          
          <h2>Key Responsibilities:</h2>
          <p>${data.responsibilities}</p>
          
          ${data.projects ? `
          <h2>Major Projects:</h2>
          <p>${data.projects}</p>` : ''}
          
          <p>During their tenure, ${data.employeeName} demonstrated a high level of professionalism, technical expertise, and commitment. Their contributions were valuable to the success of the team and the organization.</p>
          
          <p>We wish ${data.employeeName} all the best for their future endeavors.</p>
          
          <p>Sincerely,</p>
          <p>Human Resources<br />Wug Web Design</p>
        </div>
      </div>
    `;
  }
};

const emailOfferTemplate: DocumentTemplate = {
  id: "email-offer",
  name: "Email Job Offer",
  description: "Generate a professional email to send a job offer to a candidate",
  icon: <FileText className="w-5 h-5" />,
  fields: [
    { id: "candidateName", label: "Candidate Full Name", type: "text", required: true, placeholder: "John Doe" },
    { id: "candidateEmail", label: "Candidate Email", type: "text", required: true, placeholder: "john.doe@example.com" },
    { id: "position", label: "Position Title", type: "text", required: true, placeholder: "Software Engineer" },
    { id: "employmentType", label: "Employment Type", type: "select", required: true, options: [
      { value: "fulltime", label: "Full-time" },
      { value: "contractual", label: "Contractual" },
      { value: "intern", label: "Intern" }
    ]},
    { id: "department", label: "Department", type: "text", required: true, placeholder: "Engineering" },
    { id: "startDate", label: "Start Date", type: "date", required: true },
    { id: "salary", label: "Compensation", type: "text", required: true, placeholder: "₹10,00,000 per annum / ₹50,000 per month" },
    { id: "duration", label: "Duration (if applicable)", type: "text", required: false, placeholder: "6 months / 1 year" },
    { id: "location", label: "Work Location", type: "text", required: true, placeholder: "Noida, UP" },
    { id: "reportingTo", label: "Reporting Manager", type: "text", required: true, placeholder: "Jane Smith, Engineering Manager" },
    { id: "offerExpiry", label: "Offer Valid Until", type: "date", required: true },
    { id: "additionalNotes", label: "Additional Information", type: "textarea", required: false, placeholder: "Any additional details about the offer..." }
  ],
  generateDocument: (data) => {
    const currentDate = format(new Date(), "MMMM dd, yyyy");
    const startDate = format(new Date(data.startDate), "MMMM dd, yyyy");
    const offerExpiry = format(new Date(data.offerExpiry), "MMMM dd, yyyy");
    
    let employmentTypeText = "full-time";
    let durationText = "";
    
    if (data.employmentType === "contractual") {
      employmentTypeText = "contractual";
      durationText = data.duration ? ` for a period of ${data.duration}` : "";
    } else if (data.employmentType === "intern") {
      employmentTypeText = "internship";
      durationText = data.duration ? ` for a duration of ${data.duration}` : "";
    }
    
    return `
      <div class="document email-template">
        <div class="email-header">
          <p><strong>From:</strong> hr@wugweb.design</p>
          <p><strong>To:</strong> ${data.candidateEmail}</p>
          <p><strong>Subject:</strong> Job Offer: ${data.position} at Wug Web Design</p>
          <p><strong>Date:</strong> ${currentDate}</p>
        </div>
        
        <div class="email-body">
          <p>Dear ${data.candidateName},</p>
          
          <p>We are delighted to offer you the position of <strong>${data.position}</strong> with Wug Web Design on a ${employmentTypeText} basis${durationText}. Following our recent discussions, we are impressed with your background, skills and enthusiasm, and believe you would make a valuable addition to our team.</p>
          
          <p><strong>Position Details:</strong></p>
          <ul>
            <li><strong>Title:</strong> ${data.position}</li>
            <li><strong>Department:</strong> ${data.department}</li>
            <li><strong>Employment Type:</strong> ${data.employmentType === "fulltime" ? "Full-time" : data.employmentType === "contractual" ? "Contractual" : "Internship"}</li>
            ${data.duration ? `<li><strong>Duration:</strong> ${data.duration}</li>` : ''}
            <li><strong>Reporting To:</strong> ${data.reportingTo}</li>
            <li><strong>Start Date:</strong> ${startDate}</li>
            <li><strong>Location:</strong> ${data.location}</li>
          </ul>
          
          <p><strong>Compensation:</strong></p>
          <p>Your compensation will be ${data.salary}.</p>
          
          ${data.additionalNotes ? `<p><strong>Additional Information:</strong></p><p>${data.additionalNotes}</p>` : ''}
          
          <p>To accept this offer, please reply to this email confirming your acceptance by ${offerExpiry}. Upon your acceptance, our HR team will contact you with more details regarding onboarding and the necessary paperwork.</p>
          
          <p>If you have any questions regarding this offer, please don't hesitate to contact our HR department at hr@wugweb.design or call us at +91-XXX-XXX-XXXX.</p>
          
          <p>We are excited about the possibility of you joining our team and look forward to welcoming you aboard!</p>
          
          <p>Warm regards,</p>
          <p>HR Department<br />Wug Web Design</p>
        </div>
      </div>
    `;
  }
};

const consultancyAgreementTemplate: DocumentTemplate = {
  id: "consultancy-agreement",
  name: "Consultancy Agreement",
  description: "Generate a consultancy agreement between the company and a consultant",
  icon: <FileText className="w-5 h-5" />,
  fields: [
    { id: "consultantName", label: "Consultant Full Name", type: "text", required: true, placeholder: "John Doe" },
    { id: "consultantFatherName", label: "Consultant's Father's Name", type: "text", required: true, placeholder: "James Doe" },
    { id: "consultantAddress", label: "Consultant Address", type: "text", required: true, placeholder: "123 Main St, City, State" },
    { id: "consultantExpertise", label: "Consultant Expertise", type: "text", required: true, placeholder: "Digital Marketing" },
    { id: "effectiveDate", label: "Effective Date", type: "date", required: true },
    { id: "effectiveMonth", label: "Effective Month", type: "select", required: true, options: [
      { value: "January", label: "January" },
      { value: "February", label: "February" },
      { value: "March", label: "March" },
      { value: "April", label: "April" },
      { value: "May", label: "May" },
      { value: "June", label: "June" },
      { value: "July", label: "July" },
      { value: "August", label: "August" },
      { value: "September", label: "September" },
      { value: "October", label: "October" },
      { value: "November", label: "November" },
      { value: "December", label: "December" }
    ]},
    { id: "effectiveYear", label: "Effective Year", type: "text", required: true, placeholder: "2025" },
    { id: "projectDetails", label: "Project Details", type: "textarea", required: true, placeholder: "Describe the project or services to be provided" },
    { id: "compensation", label: "Compensation Amount", type: "text", required: true, placeholder: "₹50,000" },
    { id: "compensationWords", label: "Compensation Amount in Words", type: "text", required: true, placeholder: "Fifty Thousand Rupees only" },
    { id: "specificObligations", label: "Specific Obligations", type: "textarea", required: false, placeholder: "List any specific obligations of the consultant" }
  ],
  generateDocument: (data) => {
    const formattedDate = format(new Date(data.effectiveDate), "dd");
    
    return `
      <div class="document">
        <div class="document-header">
          <img src="__LOGO_URL__" alt="Company Logo" class="logo" />
          <h1>CONSULTANT AGREEMENT</h1>
        </div>
        
        <div class="document-body">
          <p>This Consultant Agreement (hereinafter "Agreement") is hereby entered into as of this the ${formattedDate} day of ${data.effectiveMonth}, ${data.effectiveYear} ("Effective Date")</p>
          
          <p><strong>BY AND BETWEEN</strong></p>
          
          <p>Wug Web Design, a private limited company incorporated under the Companies Act, 2013 having its office at WeWork Berger Delhi One, Floor 19, C-001/A2, Sector 16B, Noida, UP- 201301, IN (the "Client" which term shall include parent and subsidiary companies and permitted assigns);</p>
          
          <p><strong>AND</strong></p>
          
          <p>Mr. ${data.consultantName}, son of Mr. ${data.consultantFatherName}, currently resides at ${data.consultantAddress} (the "Consultant", which term shall include successors and permitted assigns).</p>
          
          <p>The Company and Consultant are hereinafter collectively referred to as the "Parties" and individually referred to as the "Party".</p>
          
          <p><strong>WHEREAS</strong>, the Client is in the business of web design and digital solutions.</p>
          
          <p><strong>WHEREAS</strong>, the Consultant is ${data.consultantExpertise}.</p>
          
          <p><strong>WHEREAS</strong>, the Client desires to engage the Consultant to provide certain services in the area of Consultant's expertise and the Consultant is willing to provide such services to the Company;</p>
          
          <p><strong>NOW, THEREFORE</strong>, in consideration of the mutual covenants and agreements set forth below, it is hereby covenanted and agreed by the Company and the Consultant as follows:</p>
          
          <h2>1. SERVICES/PROJECT</h2>
          <p>Subject to the terms and conditions set forth herein, Client hereby engages the Consultant to perform, and Consultant agrees to perform, professional services in relation to ${data.projectDetails} ("Work").</p>
          
          <h2>2. OBLIGATIONS AND WARRANTIES OF CONSULTANT</h2>
          <p>Upon submitting the Project to the Client, Consultant represents and warrants that the Project (or any part of it):</p>
          <ul>
            <li>is plagiarism-free and original (is not owned by any third party fully or partially and does not contain any previously produced text, "copy-pasting");</li>
            <li>complies with all requirements provided by the Client;</li>
            <li>has not been obtained by unlawful means;</li>
          </ul>
          
          ${data.specificObligations ? `<p><strong>Specific Obligations:</strong></p><p>${data.specificObligations}</p>` : ''}
          
          <h2>3. COMPENSATION</h2>
          <p>The Consultant shall be compensated for the Services with an amount of Rs. ${data.compensation}/- (Rupees ${data.compensationWords}), and no other fee or expenses shall be paid to the Consultant, unless the Client has approved such fee or expenses in writing.</p>
          <p>The completeness of the Services and work product shall be determined by the Client in its sole discretion, and the Consultant agrees to make all revisions, additions, deletions or alterations as requested by the Client.</p>
          <p>The Compensation shall be charged monthly.</p>
          <p>The Consultant shall be solely responsible for any and all taxes, social security contributions or payments, disability insurance, unemployment taxes, and other payroll type taxes or other legal requirements applicable to such compensation or to the Consultant.</p>
          
          <h2>4. OWNERSHIP AND ASSIGNMENT</h2>
          <p>The Parties agree that the Client shall have complete and sole ownership over the work product or Services performed by the Consultant under this Agreement.</p>
          <p>The Consultant hereby assigns and agrees to assign to the Client, without royalty or any other consideration except as expressly set forth herein, all worldwide right, title and interest that the Consultant may have or acquire in and to the Client.</p>
          
          <h2>5. TERM AND TERMINATION</h2>
          <p>This Agreement shall take effect immediately from the Effective Date and continue to remain in full force and effect for a period of 3 (three) months and the Parties have the option of renewing the same, unless terminated earlier in accordance with this Agreement.</p>
          
          <p>IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of the Effective Date first above written.</p>
        </div>
        
        <div class="document-footer">
          <div class="signature-section">
            <div class="signature-block">
              <p>For Client:</p>
              <div class="line"></div>
              <p>Name: ___________________</p>
              <p>Title: ___________________</p>
            </div>
            
            <div class="signature-block">
              <p>Consultant:</p>
              <div class="line"></div>
              <p>${data.consultantName}</p>
            </div>
          </div>
        </div>
      </div>
    `;
  }
};

const nonDisclosureAgreementTemplate: DocumentTemplate = {
  id: "non-disclosure-agreement",
  name: "Non-Disclosure Agreement (NDA)",
  description: "Generate a comprehensive Non-Disclosure Agreement for protecting confidential information",
  icon: <FileText className="w-5 h-5" />,
  fields: [
    { id: "partyName", label: "Other Party Name", type: "text", required: true, placeholder: "ABC Technologies Pvt Ltd" },
    { id: "partyAddress", label: "Other Party Address", type: "text", required: true, placeholder: "123 Business Park, City, State" },
    { id: "effectiveDate", label: "Effective Date", type: "date", required: true },
    { id: "proposedTransaction", label: "Proposed Transaction Description", type: "textarea", required: true, placeholder: "Software development services for..." },
    { id: "survivingPeriod", label: "Confidentiality Surviving Period (Years)", type: "select", required: true, options: [
      { value: "1", label: "1 Year" },
      { value: "2", label: "2 Years" },
      { value: "3", label: "3 Years" },
      { value: "5", label: "5 Years" }
    ]},
    { id: "governingState", label: "Governing State/Place", type: "text", required: true, placeholder: "Uttar Pradesh" }
  ],
  generateDocument: (data) => {
    const formattedDate = format(new Date(data.effectiveDate), "MMMM dd, yyyy");
    
    return `
      <div class="document">
        <div class="document-header">
          <img src="__LOGO_URL__" alt="Company Logo" class="logo" />
          <h1>NON-DISCLOSURE AGREEMENT</h1>
          <p class="date">${formattedDate}</p>
        </div>
        
        <div class="document-body">
          <p><strong>This Agreement made on this the ${format(new Date(data.effectiveDate), "do")} day of ${format(new Date(data.effectiveDate), "MMMM")}, ${format(new Date(data.effectiveDate), "yyyy")}</strong></p>
          
          <p><strong>By and Between</strong></p>
          
          <p><strong>Wug Web Design</strong>, a company incorporated under the Companies Act, 2013 and having its registered office at WeWork Berger Delhi One, Floor 19, C-001/A2, Sector 16B, Noida, UP- 201301, IN (hereinafter referred to as "Wug Web", which expression shall unless repugnant to the context or meaning thereof, include its successors in interests and assigns) of the one part;</p>
          
          <p><strong>And</strong></p>
          
          <p><strong>${data.partyName}</strong>, a company incorporated under the Companies Act, 2013 and having its registered office at ${data.partyAddress} (hereinafter referred to as "Company" which expression shall, unless repugnant to the context or meaning thereof, be deemed to include, its representatives and permitted assigns) of the Other part;</p>
          
          <p>Wug Web and COMPANY shall hereinafter be referred to as such or collectively as "Parties" and individually as "Party".</p>
          
          <p><strong>WHEREAS</strong> both the Parties herein wish to pursue discussions and negotiate with each other for the purpose of entering into a potential business arrangement in relation to ${data.proposedTransaction} ("Proposed Transaction");</p>
          
          <p><strong>AND WHEREAS</strong> the Parties contemplate that with respect to the Proposed Transaction, both the Parties may exchange certain information, material and documents relating to each other's business, assets, financial condition, operations, plans and/or prospects of their businesses (hereinafter referred to as "Confidential Information", more fully detailed in clause 1 herein below) that each Party regards as proprietary and confidential; and</p>
          
          <p><strong>AND WHEREAS</strong>, each Party wishes to review such Confidential Information of the other for the sole purpose of determining their mutual interest in engaging in the Proposed Transaction;</p>
          
          <p><strong>IN CONNECTION WITH THE ABOVE, THE PARTIES HEREBY AGREE AS FOLLOWS:</strong></p>
          
          <p>1. "Confidential and or proprietary Information" shall mean and include any information disclosed by one Party (Disclosing Party) to the other (Receiving Party) either directly or indirectly, in writing, orally, by inspection of tangible objects (including, without limitation, documents, prototypes, samples, media, documentation, discs and code). Confidential information shall include, without limitation, any materials, trade secrets, network information, configurations, trade names, trademarks, know-how, formulae, processes, algorithms, ideas, strategies, inventions, data, network configurations, system architecture, designs, flow charts, drawings, proprietary information, business operations, financial or marketing information or plans, customer or supplier lists, and business transactions of the Disclosing Party, which is disclosed to the Receiving Party or obtained by the Receiving Party through observation or examination of the foregoing.</p>
          
          <p>2. The Receiving Party shall refrain from disclosing, reproducing, summarising and/or distributing Confidential Information and confidential materials of the Disclosing Party except in connection with the Proposed Transaction.</p>
          
          <p>3. The Parties shall protect the confidentiality of each other's Confidential Information in the same manner as they protect the confidentiality of their own proprietary and confidential information of similar nature. Each Party, while acknowledging the confidential and proprietary nature of the Confidential Information agrees to take all reasonable measures at its own expense to restrain its representatives from prohibited or unauthorised disclosure or use of the Confidential Information.</p>
          
          <p>4. Confidential Information shall at all times remain the property of the Disclosing Party and may not be copied or reproduced by the Receiving Party without the Disclosing Party's prior written consent.</p>
          
          <p>5. Within seven (7) days of a written request by the Disclosing Party, the Receiving Party shall return/destroy (as may be requested in writing by the Disclosing Party or upon expiry and or earlier termination) all originals, copies, reproductions and summaries of Confidential Information provided to the Receiving Party as Confidential Information. The Receiving Party shall certify to the Disclosing Party in writing that it has satisfied its obligations under this paragraph.</p>
          
          <p>6. The provisions of this Agreement shall survive and continue after expiration or termination of this Agreement for a further period of ${data.survivingPeriod} year(s) from the date of expiration.</p>
          
          <p>7. This Agreement shall be governed by the laws of India. Both parties irrevocably submit to the exclusive jurisdiction of the Courts in ${data.governingState}, for any action or proceeding regarding this Agreement.</p>
          
          <p><strong>IN WITNESS WHEREOF</strong>, the parties hereto have executed this confidentiality agreement in duplicate by affixing the signature of the authorised representatives as of the date herein above mentioned.</p>
        </div>
        
        <div class="document-footer">
          <div class="signature-section">
            <div class="signature-block">
              <p>For Wug Web Design</p>
              <div class="line"></div>
              <p>Name: ___________________</p>
              <p>Designation: ___________________</p>
              <p>Place: ___________________</p>
              <p>Date: ___________________</p>
            </div>
            
            <div class="signature-block">
              <p>For ${data.partyName}</p>
              <div class="line"></div>
              <p>Name: ___________________</p>
              <p>Designation: ___________________</p>
              <p>Place: ___________________</p>
              <p>Date: ___________________</p>
            </div>
          </div>
        </div>
      </div>
    `;
  }
};

const offerLetterTemplate: DocumentTemplate = {
  id: "offer-letter",
  name: "Offer Letter",
  description: "Generate a formal offer letter for new employees",
  icon: <FileText className="w-5 h-5" />,
  fields: [
    { id: "candidateName", label: "Candidate Full Name", type: "text", required: true, placeholder: "John Doe" },
    { id: "candidateAddress", label: "Candidate Address", type: "text", required: true, placeholder: "123 Main St, City, State" },
    { id: "candidatePhone", label: "Candidate Phone", type: "text", required: true, placeholder: "+91 98765 43210" },
    { id: "position", label: "Position Title", type: "text", required: true, placeholder: "Software Engineer" },
    { id: "location", label: "Work Location", type: "text", required: true, placeholder: "Noida" },
    { id: "joiningDate", label: "Joining Date", type: "date", required: true },
    { id: "basicSalary", label: "Basic Salary", type: "text", required: true, placeholder: "40000" },
    { id: "hra", label: "HRA", type: "text", required: true, placeholder: "20000" },
    { id: "specialAllowance", label: "Special Allowance", type: "text", required: true, placeholder: "15000" },
    { id: "conveyance", label: "Conveyance", type: "text", required: true, placeholder: "1600" },
    { id: "medical", label: "Medical", type: "text", required: true, placeholder: "1250" },
    { id: "lta", label: "LTA", type: "text", required: true, placeholder: "3333" },
    { id: "pfEmployer", label: "PF (Employer Contribution)", type: "text", required: true, placeholder: "1800" },
    { id: "bonus", label: "Annual Bonus", type: "text", required: true, placeholder: "24000" }
  ],
  generateDocument: (data) => {
    const currentDate = format(new Date(), "MMMM dd, yyyy");
    const joiningDate = format(new Date(data.joiningDate), "MMMM dd, yyyy");
    
    // Calculate monthly and annual totals
    const basicMonthly = parseFloat(data.basicSalary) || 0;
    const hraMonthly = parseFloat(data.hra) || 0;
    const specialAllowanceMonthly = parseFloat(data.specialAllowance) || 0;
    const conveyanceMonthly = parseFloat(data.conveyance) || 0;
    const medicalMonthly = parseFloat(data.medical) || 0;
    const ltaMonthly = parseFloat(data.lta) || 0;
    const pfEmployerMonthly = parseFloat(data.pfEmployer) || 0;
    const bonusAnnual = parseFloat(data.bonus) || 0;
    
    const monthlyTotal = basicMonthly + hraMonthly + specialAllowanceMonthly + 
                         conveyanceMonthly + medicalMonthly + ltaMonthly + pfEmployerMonthly;
    
    const annualBasic = basicMonthly * 12;
    const annualHra = hraMonthly * 12;
    const annualSpecialAllowance = specialAllowanceMonthly * 12;
    const annualConveyance = conveyanceMonthly * 12;
    const annualMedical = medicalMonthly * 12;
    const annualLta = ltaMonthly * 12;
    const annualPfEmployer = pfEmployerMonthly * 12;
    
    const annualTotal = annualBasic + annualHra + annualSpecialAllowance + 
                       annualConveyance + annualMedical + annualLta + 
                       annualPfEmployer + bonusAnnual;
    
    const formatCurrency = (amount: number) => {
      return new Intl.NumberFormat('en-IN').format(amount);
    };
    
    return `
      <div class="document">
        <div class="document-header">
          <img src="__LOGO_URL__" alt="Company Logo" class="logo" />
          <h1>OFFER LETTER</h1>
          <p class="date">${currentDate}</p>
        </div>
        
        <div class="document-body">
          <p><strong>To</strong></p>
          <p>${data.candidateName}<br>${data.candidateAddress}<br>Phone No: ${data.candidatePhone}</p>
          
          <p><strong>Sub: Offer Letter</strong></p>
          
          <p>Dear ${data.candidateName.split(' ')[0]},</p>
          
          <p>We are pleased to offer you the post of <strong>${data.position}</strong> based at <strong>${data.location}</strong>.</p>
          
          <p>The compensation structure is enclosed for your reference as Annexure.</p>
          
          <p>Your employment with the Company will be subject to strict adherence to the policies and procedures of the Company.</p>
          
          <p>You will be on probation for six months.</p>
          
          <p>This offer is subjected to background verification and medical fitness.</p>
          
          <p>On acceptance of the terms of conditions as per this offer letter, you will be able to terminate your employment with the Company by giving one (1) month notice to the Company and vice versa. You shall not be eligible to avail leave during the notice period.</p>
          
          <p>We welcome you to join the Company and would be happy if you can sign the duplicate copy of this letter in token of your acceptance of the offer of employment with the Company.</p>
          
          <p>If you have any question, please clarify from the undersigned.</p>
          
          <p>With regards,</p>
          <p>____________________________<br>HR - Head</p>
          
          <div style="margin-top: 40px; border-top: 1px solid #ddd; padding-top: 20px;">
            <p>I accept the aforesaid terms & conditions and this offer of employment. I shall keep the contents of this document confidential.</p>
            <p>I will join on ${joiningDate}.</p>
            <p>Name: ${data.candidateName}</p>
            <p>Signature: _________________</p>
            <p>Date: ______________________</p>
          </div>
          
          <div style="margin-top: 40px;">
            <h2>Annexure</h2>
            <table style="width: 100%; border-collapse: collapse;">
              <tr style="border-bottom: 1px solid #ddd;">
                <th style="text-align: left; padding: 8px;">Components</th>
                <th style="text-align: right; padding: 8px;">Monthly (INR)</th>
                <th style="text-align: right; padding: 8px;">Annual (INR)</th>
              </tr>
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 8px;">Basic</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(basicMonthly)}</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(annualBasic)}</td>
              </tr>
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 8px;">HRA</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(hraMonthly)}</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(annualHra)}</td>
              </tr>
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 8px;">Special Allowance</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(specialAllowanceMonthly)}</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(annualSpecialAllowance)}</td>
              </tr>
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 8px;">Conveyance</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(conveyanceMonthly)}</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(annualConveyance)}</td>
              </tr>
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 8px;">Medical</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(medicalMonthly)}</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(annualMedical)}</td>
              </tr>
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 8px;">LTA</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(ltaMonthly)}</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(annualLta)}</td>
              </tr>
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 8px;">PF (Employer Contribution)</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(pfEmployerMonthly)}</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(annualPfEmployer)}</td>
              </tr>
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 8px;">Bonus (Annual)</td>
                <td style="text-align: right; padding: 8px;">-</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(bonusAnnual)}</td>
              </tr>
              <tr style="border-bottom: 1px solid #ddd; font-weight: bold;">
                <td style="padding: 8px;">Total</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(monthlyTotal)}</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(annualTotal)}</td>
              </tr>
              <tr style="font-weight: bold;">
                <td style="padding: 8px;">CTC</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(annualTotal/12)}</td>
                <td style="text-align: right; padding: 8px;">${formatCurrency(annualTotal)}</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
    `;
  }
};

const documentTemplates: DocumentTemplate[] = [
  jobOfferTemplate,
  offerLetterTemplate,
  emailOfferTemplate,
  ndaTemplate,
  nonDisclosureAgreementTemplate,
  consultancyAgreementTemplate,
  relievingLetterTemplate,
  experienceLetterTemplate
];

export default function DocumentGenerator() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedTemplate, setSelectedTemplate] = useState<DocumentTemplate | null>(null);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [generatedDocument, setGeneratedDocument] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(false);
  
  const handleInputChange = (fieldId: string, value: string) => {
    setFormData({
      ...formData,
      [fieldId]: value
    });
  };
  
  const handleSelectTemplate = (template: DocumentTemplate) => {
    setSelectedTemplate(template);
    setGeneratedDocument(null);
    setPreviewMode(false);
    
    // Pre-fill form with user data where applicable
    if (user) {
      const initialData: Record<string, any> = {};
      
      // Map user data to form fields based on field IDs
      template.fields.forEach(field => {
        if (field.id === 'employeeName' || field.id === 'candidateName') {
          initialData[field.id] = `${user.firstName} ${user.lastName}`;
        }
        if (field.id === 'employeeId') {
          initialData[field.id] = user.id.toString();
        }
      });
      
      setFormData(initialData);
    } else {
      setFormData({});
    }
  };
  
  const handleGenerateDocument = () => {
    // Validate required fields
    const missingFields = selectedTemplate?.fields
      .filter(field => field.required && !formData[field.id])
      .map(field => field.label);
    
    if (missingFields && missingFields.length > 0) {
      toast({
        title: "Missing Required Fields",
        description: `Please fill in the following fields: ${missingFields.join(', ')}`,
        variant: "destructive"
      });
      return;
    }
    
    // Generate document
    if (selectedTemplate) {
      try {
        const generatedHtml = selectedTemplate.generateDocument(formData);
        setGeneratedDocument(generatedHtml);
        setPreviewMode(true);
        
        toast({
          title: "Document Generated",
          description: `Your ${selectedTemplate.name} has been generated successfully.`,
          variant: "default"
        });
      } catch (error) {
        toast({
          title: "Error Generating Document",
          description: "There was an error generating your document. Please try again.",
          variant: "destructive"
        });
      }
    }
  };
  
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow && generatedDocument) {
      printWindow.document.write(`
        <html>
          <head>
            <title>${selectedTemplate?.name}</title>
            <style>
              @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
              
              body { 
                font-family: 'Inter', Arial, sans-serif; 
                margin: 0; 
                padding: 20px;
                color: #333;
                line-height: 1.6;
              }
              
              .document { 
                max-width: 800px; 
                margin: 0 auto;
                padding: 40px;
                border: 1px solid #eee;
                box-shadow: 0 4px 24px rgba(0, 0, 0, 0.05);
                background-color: #fff;
              }
              
              .document-header { 
                text-align: center; 
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 1px solid #eee;
              }
              
              .logo { 
                max-width: 120px; 
                height: auto;
                margin-bottom: 15px;
              }
              
              h1 { 
                color: #222; 
                font-weight: 700;
                margin-bottom: 10px;
              }
              
              .date, .ref { 
                color: #666;
                font-size: 0.9em;
              }
              
              .document-body { 
                line-height: 1.7;
              }
              
              .email-header {
                background-color: #f9f9f9;
                padding: 15px;
                border-radius: 5px;
                margin-bottom: 20px;
                font-family: monospace;
                font-size: 0.9em;
              }
              
              .email-body {
                padding: 0 10px;
              }
              
              p {
                margin-bottom: 1em;
              }
              
              ul {
                padding-left: 25px;
              }
              
              li {
                margin-bottom: 0.5em;
              }
              
              h2 { 
                color: #222; 
                margin-top: 25px;
                font-weight: 600;
                font-size: 1.3em;
              }
              
              .document-footer { 
                margin-top: 50px;
                padding-top: 30px;
                border-top: 1px solid #eee;
              }
              
              .signature-section { 
                display: flex; 
                justify-content: space-between;
                flex-wrap: wrap;
              }
              
              .signature-block { 
                margin-top: 30px;
                min-width: 200px;
                margin-right: 20px;
              }
              
              .line { 
                border-bottom: 1px solid #000; 
                width: 200px; 
                margin: 30px 0 10px;
              }
              
              table {
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
              }
              
              th, td {
                padding: 10px;
                text-align: left;
                border-bottom: 1px solid #eee;
              }
              
              th {
                font-weight: 600;
                color: #222;
              }
              
              @media print {
                body {
                  padding: 0;
                  margin: 0;
                }
                
                .document {
                  box-shadow: none;
                  border: none;
                  padding: 20px 0;
                  max-width: 100%;
                }
              }
            </style>
          </head>
          <body>
            ${generatedDocument.replace("__LOGO_URL__", window.location.origin + "/wugweb-logo.png")}
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      printWindow.print();
    }
  };
  
  const handleDownload = () => {
    if (generatedDocument && selectedTemplate) {
      const htmlContent = generatedDocument.replace("__LOGO_URL__", window.location.origin + "/wugweb-logo.png");
      const blob = new Blob([`
        <html>
          <head>
            <title>${selectedTemplate.name}</title>
            <style>
              @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
              
              body { 
                font-family: 'Inter', Arial, sans-serif; 
                margin: 0; 
                padding: 20px;
                color: #333;
                line-height: 1.6;
              }
              
              .document { 
                max-width: 800px; 
                margin: 0 auto;
                padding: 40px;
                border: 1px solid #eee;
                box-shadow: 0 4px 24px rgba(0, 0, 0, 0.05);
                background-color: #fff;
              }
              
              .document-header { 
                text-align: center; 
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 1px solid #eee;
              }
              
              .logo { 
                max-width: 120px; 
                height: auto;
                margin-bottom: 15px;
              }
              
              h1 { 
                color: #222; 
                font-weight: 700;
                margin-bottom: 10px;
              }
              
              .date, .ref { 
                color: #666;
                font-size: 0.9em;
              }
              
              .document-body { 
                line-height: 1.7;
              }
              
              .email-header {
                background-color: #f9f9f9;
                padding: 15px;
                border-radius: 5px;
                margin-bottom: 20px;
                font-family: monospace;
                font-size: 0.9em;
              }
              
              .email-body {
                padding: 0 10px;
              }
              
              p {
                margin-bottom: 1em;
              }
              
              ul {
                padding-left: 25px;
              }
              
              li {
                margin-bottom: 0.5em;
              }
              
              h2 { 
                color: #222; 
                margin-top: 25px;
                font-weight: 600;
                font-size: 1.3em;
              }
              
              .document-footer { 
                margin-top: 50px;
                padding-top: 30px;
                border-top: 1px solid #eee;
              }
              
              .signature-section { 
                display: flex; 
                justify-content: space-between;
                flex-wrap: wrap;
              }
              
              .signature-block { 
                margin-top: 30px;
                min-width: 200px;
                margin-right: 20px;
              }
              
              .line { 
                border-bottom: 1px solid #000; 
                width: 200px; 
                margin: 30px 0 10px;
              }
              
              table {
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
              }
              
              th, td {
                padding: 10px;
                text-align: left;
                border-bottom: 1px solid #eee;
              }
              
              th {
                font-weight: 600;
                color: #222;
              }
              
              @media print {
                body {
                  padding: 0;
                  margin: 0;
                }
                
                .document {
                  box-shadow: none;
                  border: none;
                  padding: 20px 0;
                  max-width: 100%;
                }
              }
            </style>
          </head>
          <body>
            ${htmlContent}
          </body>
        </html>
      `], { type: 'text/html' });
      
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${selectedTemplate.name.replace(/\s+/g, '-').toLowerCase()}-${format(new Date(), 'yyyy-MM-dd')}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };
  
  const handleBackToEdit = () => {
    setPreviewMode(false);
  };
  
  const renderTemplateSelection = () => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {documentTemplates.map((template) => (
          <Card 
            key={template.id} 
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => handleSelectTemplate(template)}
          >
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  {template.icon}
                  {template.name}
                </CardTitle>
              </div>
              <CardDescription>{template.description}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </div>
    );
  };
  
  const renderFormFields = () => {
    if (!selectedTemplate) return null;
    
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            {selectedTemplate.icon}
            <h2 className="text-xl font-semibold">{selectedTemplate.name}</h2>
          </div>
          <Button variant="ghost" onClick={() => setSelectedTemplate(null)}>Back to Templates</Button>
        </div>
        
        <div className="space-y-4">
          {selectedTemplate.fields.map((field) => (
            <div key={field.id} className="space-y-2">
              <Label htmlFor={field.id}>
                {field.label}
                {field.required && <span className="text-red-500 ml-1">*</span>}
              </Label>
              
              {field.type === 'text' && (
                <Input
                  id={field.id}
                  value={formData[field.id] || ''}
                  onChange={(e) => handleInputChange(field.id, e.target.value)}
                  placeholder={field.placeholder}
                  required={field.required}
                />
              )}
              
              {field.type === 'date' && (
                <Input
                  id={field.id}
                  type="date"
                  value={formData[field.id] || ''}
                  onChange={(e) => handleInputChange(field.id, e.target.value)}
                  required={field.required}
                />
              )}
              
              {field.type === 'textarea' && (
                <Textarea
                  id={field.id}
                  value={formData[field.id] || ''}
                  onChange={(e) => handleInputChange(field.id, e.target.value)}
                  placeholder={field.placeholder}
                  required={field.required}
                />
              )}
              
              {field.type === 'select' && field.options && (
                <Select
                  value={formData[field.id] || ''}
                  onValueChange={(value) => handleInputChange(field.id, value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select an option" />
                  </SelectTrigger>
                  <SelectContent>
                    {field.options.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          ))}
        </div>
        
        <div className="flex justify-end pt-4">
          <Button onClick={handleGenerateDocument}>
            <FileText className="mr-2 h-4 w-4" />
            Generate Document
          </Button>
        </div>
      </div>
    );
  };
  
  const renderDocumentPreview = () => {
    if (!generatedDocument || !selectedTemplate) return null;
    
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-500" />
            <h2 className="text-xl font-semibold">{selectedTemplate.name} Preview</h2>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleBackToEdit}>
              Edit
            </Button>
            <Button variant="outline" onClick={handlePrint}>
              <Printer className="mr-2 h-4 w-4" />
              Print
            </Button>
            <Button onClick={handleDownload}>
              <Download className="mr-2 h-4 w-4" />
              Download
            </Button>
          </div>
        </div>
        
        <Card className="border p-6">
          <div
            className="preview-content"
            dangerouslySetInnerHTML={{
              __html: generatedDocument.replace("__LOGO_URL__", "/wugweb-logo.png")
            }}
          />
        </Card>
      </div>
    );
  };
  
  return (
    <Layout title="Document Generator">
      <div className="p-4 sm:p-6">
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-1">
            <FileText className="h-5 w-5 text-primary" />
            <h1 className="text-2xl font-semibold">Document Generator</h1>
          </div>
          <p className="text-neutral-medium">Generate various HR documents by filling in the required information</p>
        </div>
        
        <Card>
          <CardContent className="p-6">
            {!selectedTemplate && renderTemplateSelection()}
            {selectedTemplate && !previewMode && renderFormFields()}
            {selectedTemplate && previewMode && renderDocumentPreview()}
          </CardContent>
        </Card>
        
        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5 text-blue-500" />
                Document Generation Tips
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-neutral-medium">
                <li className="flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5" />
                  <span>All generated documents follow company branding and legal guidelines.</span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5" />
                  <span>Review all documents carefully before sharing with recipients.</span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5" />
                  <span>For special cases requiring customization, please contact the HR department.</span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5" />
                  <span>All generated documents are for internal use only and are not stored in the system.</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}