import { useState } from "react";
import Layout from "@/components/layout";
import { useDocuments } from "@/hooks/useDocuments";
import DocumentCard from "@/components/document-card";
import FileUpload from "@/components/file-upload";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SearchIcon, FileUpIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Document } from "@shared/schema";

export default function Documents() {
  const { documents, categories, isLoadingDocuments, isLoadingCategories } = useDocuments();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("all");
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);

  // Filter documents based on search query and selected category
  const filteredDocuments = documents?.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategoryId === "all" || 
                           (selectedCategoryId === "uncategorized" && !doc.categoryId) || 
                           (doc.categoryId?.toString() === selectedCategoryId);
    return matchesSearch && matchesCategory;
  });

  // Get category name by id
  const getCategoryName = (categoryId: number | null | undefined) => {
    if (!categoryId) return null;
    return categories?.find(cat => cat.id === categoryId)?.name || null;
  };

  return (
    <Layout title="Documents">
      <div className="p-4 sm:p-6 lg:p-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div className="relative w-full md:w-96">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-medium" />
            <Input
              placeholder="Search documents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <FileUpIcon className="w-4 h-4 mr-2" />
                Upload Document
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Upload Document</DialogTitle>
                <DialogDescription>
                  Upload a new document to your repository
                </DialogDescription>
              </DialogHeader>
              <FileUpload />
            </DialogContent>
          </Dialog>
        </div>
        
        <Tabs defaultValue="all" className="w-full" onValueChange={setSelectedCategoryId}>
          <div className="overflow-x-auto">
            <TabsList className="mb-6">
              <TabsTrigger value="all">All Documents</TabsTrigger>
              {categories?.map((category) => (
                <TabsTrigger key={category.id} value={category.id.toString()}>
                  {category.name}
                </TabsTrigger>
              ))}
              <TabsTrigger value="uncategorized">Uncategorized</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value={selectedCategoryId} className="pt-2">
            {isLoadingDocuments || isLoadingCategories ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array(6).fill(null).map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start">
                        <Skeleton className="w-10 h-10 rounded mr-3 flex-shrink-0" />
                        <div>
                          <Skeleton className="h-5 w-40 mb-2" />
                          <Skeleton className="h-4 w-32 mb-2" />
                          <Skeleton className="h-6 w-24" />
                        </div>
                      </div>
                      <Skeleton className="w-8 h-8 rounded-full" />
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredDocuments && filteredDocuments.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredDocuments.map((document) => (
                  <DocumentCard 
                    key={document.id} 
                    document={document}
                    category={getCategoryName(document.categoryId)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-neutral-light/30 flex items-center justify-center">
                  <FileUpIcon className="w-8 h-8 text-neutral-medium" />
                </div>
                <h3 className="text-lg font-medium mb-2">No documents found</h3>
                <p className="text-neutral-medium mb-6">
                  {searchQuery 
                    ? "Try a different search term or category" 
                    : "Upload your first document to get started"}
                </p>
                <Button onClick={() => setUploadDialogOpen(true)}>
                  <FileUpIcon className="w-4 h-4 mr-2" />
                  Upload Document
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
