import Layout from "@/components/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { UserIcon, PhoneIcon, MailIcon, MapPinIcon, SearchIcon } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { getInitials } from "@/lib/utils";

// Mock employee data
const employees = [
  {
    id: 1,
    firstName: "Rahul",
    lastName: "Sharma",
    position: "Software Engineer",
    department: "Engineering",
    email: "rahul.sharma@example.com",
    phone: "+91 98765 43210",
    location: "Bangalore",
    avatar: null
  },
  {
    id: 2,
    firstName: "Priya",
    lastName: "Patel",
    position: "Product Manager",
    department: "Product",
    email: "priya.patel@example.com",
    phone: "+91 87654 32109",
    location: "Mumbai",
    avatar: null
  },
  {
    id: 3,
    firstName: "Amit",
    lastName: "Verma",
    position: "UX Designer",
    department: "Design",
    email: "amit.verma@example.com",
    phone: "+91 76543 21098",
    location: "Hyderabad",
    avatar: null
  },
  {
    id: 4,
    firstName: "Sneha",
    lastName: "Gupta",
    position: "Marketing Specialist",
    department: "Marketing",
    email: "sneha.gupta@example.com",
    phone: "+91 65432 10987",
    location: "Delhi",
    avatar: null
  },
  {
    id: 5,
    firstName: "Vikram",
    lastName: "Singh",
    position: "HR Manager",
    department: "Human Resources",
    email: "vikram.singh@example.com",
    phone: "+91 54321 09876",
    location: "Pune",
    avatar: null
  },
  {
    id: 6,
    firstName: "Neha",
    lastName: "Kumar",
    position: "Finance Analyst",
    department: "Finance",
    email: "neha.kumar@example.com",
    phone: "+91 43210 98765",
    location: "Chennai",
    avatar: null
  }
];

export default function EmployeeDirectory() {
  const [searchTerm, setSearchTerm] = useState("");
  
  // Filter employees based on search term
  const filteredEmployees = employees.filter(employee => {
    const fullName = `${employee.firstName} ${employee.lastName}`.toLowerCase();
    const department = employee.department.toLowerCase();
    const position = employee.position.toLowerCase();
    const search = searchTerm.toLowerCase();
    
    return fullName.includes(search) || 
           department.includes(search) || 
           position.includes(search);
  });
  
  return (
    <Layout title="Employee Directory">
      <div className="p-4 sm:p-6 lg:p-8">
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <CardTitle>Employee Directory</CardTitle>
                <CardDescription>
                  Find and connect with colleagues
                </CardDescription>
              </div>
              <div className="mt-4 sm:mt-0 relative">
                <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-medium" />
                <Input 
                  className="pl-10"
                  placeholder="Search employees..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredEmployees.map((employee) => (
                <div 
                  key={employee.id}
                  className="border rounded-lg p-4 hover:border-primary hover:shadow-sm transition-all"
                >
                  <div className="flex items-start">
                    <Avatar className="w-12 h-12 mr-4">
                      <AvatarImage src={employee.avatar || ""} alt={`${employee.firstName} ${employee.lastName}`} />
                      <AvatarFallback className="bg-primary text-white">
                        {getInitials(employee.firstName, employee.lastName)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">{employee.firstName} {employee.lastName}</h3>
                      <p className="text-neutral-medium text-sm">{employee.position}</p>
                      <p className="text-neutral-medium text-sm">{employee.department}</p>
                    </div>
                  </div>
                  
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center text-sm">
                      <MailIcon className="w-4 h-4 mr-2 text-neutral-medium" />
                      <span className="text-neutral-dark">{employee.email}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <PhoneIcon className="w-4 h-4 mr-2 text-neutral-medium" />
                      <span className="text-neutral-dark">{employee.phone}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <MapPinIcon className="w-4 h-4 mr-2 text-neutral-medium" />
                      <span className="text-neutral-dark">{employee.location}</span>
                    </div>
                  </div>
                  
                  <div className="mt-4 flex justify-end">
                    <Button variant="outline" size="sm">View Profile</Button>
                  </div>
                </div>
              ))}
            </div>
            
            {filteredEmployees.length === 0 && (
              <div className="text-center py-12">
                <UserIcon className="w-12 h-12 mx-auto text-neutral-light" />
                <h3 className="mt-4 font-medium">No employees found</h3>
                <p className="text-neutral-medium">Try adjusting your search terms</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}