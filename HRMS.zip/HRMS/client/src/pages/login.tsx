import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { loginSchema } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { 
  UserPlus, 
  ArrowRight, 
  KeyRound, 
  Mail, 
  Check, 
  UserCog, 
  User,
  Info as InfoIcon
} from "lucide-react";
import wugwebLogo from "../assets/wugweb-logo.png";

export default function Login() {
  const [, setLocation] = useLocation();
  const { login, isLoggingIn, user } = useAuth();
  const [error, setError] = useState<string | null>(null);
  const [rememberMe, setRememberMe] = useState(false);
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
  const [loginRole, setLoginRole] = useState<'employee' | 'admin'>('employee');
  const { toast } = useToast();

  // Redirect to dashboard if already logged in
  useEffect(() => {
    if (user) {
      setLocation("/dashboard");
    }
  }, [user, setLocation]);

  // Extended schema for login with remember me
  const extendedLoginSchema = loginSchema.extend({
    rememberMe: z.boolean().optional(),
  });

  const form = useForm<z.infer<typeof extendedLoginSchema>>({
    resolver: zodResolver(extendedLoginSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false,
    },
  });

  // Form for forgot password
  const forgotPasswordForm = useForm({
    resolver: zodResolver(
      z.object({
        email: z.string().email("Please enter a valid email address"),
      })
    ),
    defaultValues: {
      email: "",
    },
  });

  const onSubmit = async (values: z.infer<typeof extendedLoginSchema>) => {
    setError(null);
    try {
      // In a real application, you would pass the role and rememberMe values
      // to set the appropriate session parameters
      await login({
        username: values.username,
        password: values.password,
        // We're only using the login schema fields here, but in a real app
        // you could use the role and remember me values:
        // role: loginRole,
        // rememberMe: values.rememberMe
      });
      
      // For demonstration, show which role was selected
      toast({
        title: `Logged in as ${loginRole === 'admin' ? 'Administrator' : 'Employee'}`,
        description: "In a production app, this would determine your access level and permissions.",
      });
      
    } catch (err: any) {
      setError(err.message || "Login failed. Please try again.");
    }
  };

  const handleForgotPassword = async (values: { email: string }) => {
    // In a real application, this would trigger a password reset email
    toast({
      title: "Password Reset Email Sent",
      description: `If an account exists for ${values.email}, we've sent password reset instructions.`,
    });
    setIsForgotPasswordOpen(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-lightest p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 mb-4">
            <img src={wugwebLogo} alt="Wugweb Logo" className="w-full h-full" />
          </div>
          <h1 className="text-3xl font-heading font-semibold text-primary">Staff Hub</h1>
          <p className="mt-2 text-neutral-medium">Employee Portal</p>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Sign In</CardTitle>
            <CardDescription>
              Enter your credentials to access your account
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="mb-5">
                  <label className="text-sm font-medium mb-2 block">Login as:</label>
                  <RadioGroup 
                    value={loginRole} 
                    onValueChange={(value) => setLoginRole(value as 'employee' | 'admin')}
                    className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="employee" id="employee" />
                      <label htmlFor="employee" className="flex items-center cursor-pointer">
                        <User className="h-4 w-4 mr-2 text-neutral-medium" />
                        <span>Employee</span>
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="admin" id="admin" />
                      <label htmlFor="admin" className="flex items-center cursor-pointer">
                        <UserCog className="h-4 w-4 mr-2 text-neutral-medium" />
                        <span>Administrator</span>
                      </label>
                    </div>
                  </RadioGroup>
                </div>
                
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your username" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Enter your password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex items-center space-x-2 mb-6">
                  <Checkbox 
                    id="rememberMe" 
                    checked={rememberMe} 
                    onCheckedChange={(checked) => {
                      setRememberMe(checked as boolean);
                      form.setValue('rememberMe', checked as boolean);
                    }} 
                  />
                  <label
                    htmlFor="rememberMe"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Keep me logged in
                  </label>
                </div>
                
                <Button type="submit" className="w-full" disabled={isLoggingIn}>
                  {isLoggingIn ? "Signing in..." : "Sign In"}
                </Button>
                
                <div className="flex justify-between mt-4 text-sm">
                  <Dialog open={isForgotPasswordOpen} onOpenChange={setIsForgotPasswordOpen}>
                    <DialogTrigger asChild>
                      <Button variant="link" className="h-auto p-0">
                        Forgot password?
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Reset Your Password</DialogTitle>
                        <DialogDescription>
                          Enter your email address and we'll send you a link to reset your password.
                        </DialogDescription>
                      </DialogHeader>
                      
                      <Form {...forgotPasswordForm}>
                        <form onSubmit={forgotPasswordForm.handleSubmit(handleForgotPassword)} className="space-y-4">
                          <FormField
                            control={forgotPasswordForm.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email</FormLabel>
                                <FormControl>
                                  <Input placeholder="name@example.com" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <DialogFooter className="mt-4">
                            <Button variant="outline" type="button" onClick={() => setIsForgotPasswordOpen(false)}>
                              Cancel
                            </Button>
                            <Button type="submit">
                              <Mail className="mr-2 h-4 w-4" />
                              Send Reset Link
                            </Button>
                          </DialogFooter>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex flex-col items-center space-y-4">
            <div className="space-y-2">
              <p className="text-sm text-neutral-medium">
                Demo credentials: username: <strong>emily</strong>, password: <strong>emily123</strong>
              </p>
            </div>
            
            <div className="w-full">
              <Link href="/pre-onboarding">
                <Button variant="outline" className="w-full flex items-center justify-center" type="button">
                  <UserPlus className="mr-2 h-4 w-4" />
                  New User? Onboard Here
                </Button>
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
