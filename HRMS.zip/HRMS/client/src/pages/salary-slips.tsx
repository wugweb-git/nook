import Layout from "@/components/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileIcon, DownloadIcon, CalendarIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/utils";

// Mock data for salary slips
const salarySlips = [
  {
    id: 1,
    period: "April 2025",
    date: new Date(2025, 3, 30),
    amount: "₹65,000"
  },
  {
    id: 2,
    period: "March 2025",
    date: new Date(2025, 2, 31),
    amount: "₹65,000"
  },
  {
    id: 3,
    period: "February 2025",
    date: new Date(2025, 1, 28),
    amount: "₹65,000"
  },
  {
    id: 4,
    period: "January 2025",
    date: new Date(2025, 0, 31),
    amount: "₹65,000"
  },
  {
    id: 5,
    period: "December 2024",
    date: new Date(2024, 11, 31),
    amount: "₹62,000"
  },
  {
    id: 6,
    period: "November 2024",
    date: new Date(2024, 10, 30),
    amount: "₹62,000"
  }
];

export default function SalarySlips() {
  return (
    <Layout title="Salary Slips">
      <div className="p-4 sm:p-6 lg:p-8">
        <Card>
          <CardHeader>
            <CardTitle>Salary Slips</CardTitle>
            <CardDescription>
              View and download your salary slips
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {salarySlips.map((slip) => (
                <div 
                  key={slip.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-primary-light flex items-center justify-center text-primary mr-4">
                      <FileIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-medium">{slip.period} Salary Slip</h3>
                      <div className="flex items-center mt-1 text-neutral-medium text-sm">
                        <CalendarIcon className="w-4 h-4 mr-1" />
                        <span>{formatDate(slip.date)}</span>
                        <span className="mx-2">•</span>
                        <span>{slip.amount}</span>
                      </div>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="flex items-center">
                    <DownloadIcon className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}